from engine.data_loader import load_json


ABILITY_BYPASS_NAMES = {
    "Mold Breaker",
    "Teravolt",
    "Turboblaze",
}

NON_IGNORABLE_DEFENSIVE_ABILITIES = {
    "Prism Armor",
    "Full Metal Body",
    "Shadow Shield",
}

SOUND_TAGS = {
    "sound",
    "soundbased",
    "soundmove",
}

BULLET_TAGS = {
    "bullet",
    "ballbomb",
    "ballorb",
    "bomb",
    "bulletproof",
}


WEATHER_SETTING_ABILITIES = {
    "Drought": "Sun",
    "Drizzle": "Rain",
    "Sand Stream": "Sandstorm",
    "Snow Warning": "Hail",
}


SILVALLY_MEMORY_TYPE_MAP = {
    "bug memory": "Bug",
    "dark memory": "Dark",
    "dragon memory": "Dragon",
    "electric memory": "Electric",
    "fairy memory": "Fairy",
    "fighting memory": "Fighting",
    "fire memory": "Fire",
    "flying memory": "Flying",
    "ghost memory": "Ghost",
    "grass memory": "Grass",
    "ground memory": "Ground",
    "ice memory": "Ice",
    "poison memory": "Poison",
    "psychic memory": "Psychic",
    "rock memory": "Rock",
    "steel memory": "Steel",
    "water memory": "Water",
}


def get_silvally_memory_type(pokemon):
    """Return Silvally's active RKS System type from its held Memory."""

    if not isinstance(pokemon, dict):
        return None

    pokemon_name = str(
        pokemon.get("Pokemon") or ""
    ).strip().casefold()

    if pokemon_name != "silvally":
        return None

    held_item = " ".join(
        str(
            pokemon.get("Held Item")
            or ""
        ).strip().casefold().split()
    )

    return SILVALLY_MEMORY_TYPE_MAP.get(
        held_item
    )


def get_effective_pokemon_types(pokemon):
    """Return the Pokémon's active defensive typing.

    Silvally is always Normal without a Memory. With a Memory, RKS System
    changes it to the corresponding single type. Type: Null and every other
    Pokémon retain their stored types.
    """

    if not isinstance(pokemon, dict):
        return [None, None]

    pokemon_name = str(
        pokemon.get("Pokemon") or ""
    ).strip().casefold()

    if pokemon_name == "silvally":
        memory_type = get_silvally_memory_type(
            pokemon
        )
        return [
            memory_type or "Normal",
            "",
        ]

    return [
        pokemon.get("Type1"),
        pokemon.get("Type2"),
    ]


def get_effective_move_type(attacker, move):
    """Return a move's deterministic active type for this attacker."""

    if not isinstance(move, dict):
        return None

    move_name = str(
        move.get("Move") or ""
    ).strip().casefold()

    if move_name == "multi-attack":
        memory_type = get_silvally_memory_type(
            attacker
        )
        if memory_type:
            return memory_type

    return move.get("Type")


def get_guaranteed_weather(attacker, defender):
    """Return deterministic entry weather established by the matchup.

    If both Pokémon set the same weather, that weather is guaranteed. If only
    one sets weather, that weather is guaranteed. If both set different weather,
    the Compass does not infer activation order and treats the final weather as
    unknown.
    """

    attacker_weather = WEATHER_SETTING_ABILITIES.get(
        attacker.get("Ability")
    )
    defender_weather = WEATHER_SETTING_ABILITIES.get(
        defender.get("Ability")
    )

    if attacker_weather and defender_weather:
        if attacker_weather == defender_weather:
            return attacker_weather
        return None

    return attacker_weather or defender_weather


def get_weather_damage_multiplier(move, weather):
    """Return deterministic weather's direct damage modifier."""

    move_type = move.get("Type")

    if weather == "Sun":
        if move_type == "Fire":
            return 1.5
        if move_type == "Water":
            return 0.5

    if weather == "Rain":
        if move_type == "Water":
            return 1.5
        if move_type == "Fire":
            return 0.5

    return 1


def get_weather_defense_stat_multiplier(
    defender,
    move,
    weather,
):
    """Return deterministic weather's modifier to the targeted defense."""

    if weather != "Sandstorm":
        return 1

    defender_types = set(
        get_effective_pokemon_types(
            defender
        )
    )

    if "Rock" not in defender_types:
        return 1

    # In Sword/Shield, sandstorm raises Rock-type Special Defense by 50%.
    # Psyshock/Psystrike-style moves are Special but target DEF, so they do not
    # receive this modifier.
    if (
        move.get("Category") == "Special"
        and move.get("DamageMethod") != "TargetDEFasSPD"
    ):
        return 1.5

    return 1


def load_type_chart():
    return load_json("type_chart")


def get_type_multiplier(attack_type, defender_types):
    type_chart = load_type_chart()
    multiplier = 1

    for defender_type in defender_types:
        if defender_type:
            multiplier *= type_chart.get(
                attack_type,
                {},
            ).get(
                defender_type,
                1,
            )

    return multiplier


def normalize_mechanics_tag(value):
    if not isinstance(value, str):
        return ""

    return "".join(
        character
        for character in value.lower()
        if character.isalnum()
    )


def move_has_any_tag(move, accepted_tags):
    raw_tags = move.get("MechanicsTags")

    if not isinstance(raw_tags, list):
        return False

    normalized_tags = {
        normalize_mechanics_tag(tag)
        for tag in raw_tags
        if isinstance(tag, str)
    }

    return bool(
        normalized_tags.intersection(
            accepted_tags
        )
    )


def move_is_sound_based(move):
    return move_has_any_tag(
        move,
        SOUND_TAGS,
    )


def move_is_ball_or_bomb(move):
    return move_has_any_tag(
        move,
        BULLET_TAGS,
    )


def move_makes_contact(move):
    return move.get("MakesContact") in {
        True,
        "TRUE",
        "True",
        "Yes",
        "Y",
        1,
    }


def attacker_ignores_defender_ability(
    attacker,
    defender,
    ability_rules,
    move=None,
):
    if not attacker:
        return False

    attacker_ability = attacker.get("Ability")
    defender_ability = defender.get("Ability")

    if defender_ability in NON_IGNORABLE_DEFENSIVE_ABILITIES:
        return False

    if move and move.get("IgnoresDefenderAbility"):
        return True

    if not attacker_ability:
        return False

    if attacker_ability in ABILITY_BYPASS_NAMES:
        return True

    return any(
        rule.get("Ability") == attacker_ability
        and rule.get("Effect") == "AbilityBypass"
        for rule in ability_rules
    )


def get_stab_multiplier(
    move_type,
    attacker_types,
    attacker=None,
    ability_rules=None,
):
    if move_type not in attacker_types:
        return 1

    if attacker is None:
        return 1.5

    if ability_rules is None:
        ability_rules = []

    ability_name = attacker.get("Ability")

    for rule in ability_rules:
        if rule.get("Ability") != ability_name:
            continue

        if (
            rule.get("Effect") == "STABBoost"
            and rule.get("TargetType") == "STAB"
        ):
            return rule.get(
                "Modifier",
                1.5,
            )

    return 1.5


def get_item_record(item_name, items):
    if not item_name:
        return None

    for item in items:
        if item.get("Item") == item_name:
            return item

    return None


def item_move_filters_match(item, move):
    move_type_affected = item.get(
        "MoveTypeAffected"
    )
    move_category_affected = item.get(
        "MoveCategoryAffected"
    )

    type_matches = (
        move_type_affected
        in [
            None,
            "None",
            move.get("Type"),
        ]
    )

    category_matches = (
        move_category_affected
        in [
            None,
            "None",
            move.get("Category"),
        ]
    )

    return (
        type_matches
        and category_matches
    )


def get_item_damage_multiplier(
    attacker,
    defender,
    move,
    items,
    effectiveness=1,
    effective_power=None,
):
    item = get_item_record(
        attacker.get("Held Item"),
        items,
    )

    if item is None:
        return 1

    if item.get("EffectType") != "DamageMultiplier":
        return 1

    if item.get("AppliesTo") != "Offense":
        return 1

    if not item_move_filters_match(
        item,
        move,
    ):
        return 1

    condition = item.get("Condition")

    if (
        condition == "SuperEffective"
        and effectiveness <= 1
    ):
        return 1

    if condition == "DamagingMove":
        if move.get("Category") == "Status":
            return 1

        modeled_power = (
            effective_power
            if effective_power is not None
            else move.get("Power")
        )

        if not modeled_power:
            return 1

    return item.get(
        "Multiplier",
        1,
    )


def get_item_attack_stat_multiplier(
    attacker,
    move,
    items,
):
    item = get_item_record(
        attacker.get("Held Item"),
        items,
    )

    if item is None:
        return 1

    if item.get("EffectType") != "StatMultiplier":
        return 1

    if item.get("AppliesTo") != "Offense":
        return 1

    if not item_move_filters_match(
        item,
        move,
    ):
        return 1

    stat_affected = item.get("StatAffected")
    move_category = move.get("Category")

    if (
        stat_affected == "ATK"
        and move_category != "Physical"
    ):
        return 1

    if (
        stat_affected == "SPA"
        and move_category != "Special"
    ):
        return 1

    return item.get(
        "Multiplier",
        1,
    )


def get_item_defense_stat_multiplier(
    defender,
    move,
    items,
):
    item = get_item_record(
        defender.get("Held Item"),
        items,
    )

    if item is None:
        return 1

    if item.get("EffectType") != "StatMultiplier":
        return 1

    if item.get("AppliesTo") != "Defense":
        return 1

    stat_affected = item.get("StatAffected")
    damage_method = move.get("DamageMethod")
    move_category = move.get("Category")

    targets_defense = (
        move_category == "Physical"
        or damage_method == "TargetDEFasSPD"
    )

    targets_special_defense = (
        move_category == "Special"
        and damage_method != "TargetDEFasSPD"
    )

    if stat_affected == "DEF/SPD":
        return item.get(
            "Multiplier",
            1,
        )

    if (
        stat_affected == "DEF"
        and targets_defense
    ):
        return item.get(
            "Multiplier",
            1,
        )

    if (
        stat_affected == "SPD"
        and targets_special_defense
    ):
        return item.get(
            "Multiplier",
            1,
        )

    return 1


def get_item_speed_multiplier(
    pokemon,
    items,
):
    item = get_item_record(
        pokemon.get("Held Item"),
        items,
    )

    if item is None:
        return 1

    if (
        item.get("EffectType") == "StatMultiplier"
        and item.get("AppliesTo") == "Speed"
        and item.get("StatAffected") == "SPE"
    ):
        return item.get(
            "Multiplier",
            1,
        )

    return 1


def get_item_immunity_multiplier(
    defender,
    move,
    items,
):
    item = get_item_record(
        defender.get("Held Item"),
        items,
    )

    if item is None:
        return 1

    if item.get("EffectType") != "Immunity":
        return 1

    if item.get("AppliesTo") != "Defense":
        return 1

    if item.get("MoveTypeAffected") == move.get("Type"):
        return item.get(
            "Multiplier",
            0,
        )

    return 1


def get_item_multiplier(
    item_name,
    move,
    items,
    effective_power=None,
):
    """Backward-compatible alias for simple offensive item boosts."""

    attacker = {
        "Held Item": item_name,
    }

    return get_item_damage_multiplier(
        attacker,
        {},
        move,
        items,
        effectiveness=1,
        effective_power=effective_power,
    )


def ability_rule_applies(
    rule,
    move,
    effectiveness,
):
    effect = rule.get("Effect")
    target_type = rule.get("TargetType")
    move_type = move.get("Type")
    move_category = move.get("Category")

    if effect == "Immunity":
        if target_type == move_type:
            return True

        if (
            target_type == "Sound"
            and move_is_sound_based(move)
        ):
            return True

        if (
            target_type == "Bullet"
            and move_is_ball_or_bomb(move)
        ):
            return True

        if (
            target_type == "NotSuperEffective"
            and effectiveness <= 1
        ):
            return True

        return False

    if effect == "Reduction":
        if target_type == move_type:
            return True

        if (
            target_type == "SuperEffective"
            and effectiveness > 1
        ):
            return True

        if target_type == move_category:
            return True

        if (
            target_type == "Contact"
            and move_makes_contact(move)
        ):
            return True

        return False

    if effect == "Vulnerability":
        if target_type == move_type:
            return True

        if target_type == move_category:
            return True

        if (
            target_type == "Contact"
            and move_makes_contact(move)
        ):
            return True

    return False


def get_applicable_ability_rules(
    defender,
    move,
    ability_rules,
    effectiveness=1,
    attacker=None,
):
    """Return defensive Ability rules that apply to this specific move."""

    ability_name = defender.get("Ability")

    if not ability_name:
        return []

    if attacker_ignores_defender_ability(
        attacker,
        defender,
        ability_rules,
        move,
    ):
        return []

    return [
        rule
        for rule in ability_rules
        if (
            rule.get("Ability") == ability_name
            and rule.get("Effect")
            in {
                "Immunity",
                "Reduction",
                "Vulnerability",
            }
            and ability_rule_applies(
                rule,
                move,
                effectiveness,
            )
        )
    ]


def get_ability_multiplier(
    defender,
    move,
    ability_rules,
    effectiveness=1,
    attacker=None,
):
    multiplier = 1

    for rule in get_applicable_ability_rules(
        defender,
        move,
        ability_rules,
        effectiveness,
        attacker,
    ):
        modifier = rule.get(
            "Modifier",
            1,
        )

        if rule.get("Effect") == "Immunity":
            return modifier

        multiplier *= modifier

    return multiplier


def get_attack_stat_multiplier(
    attacker,
    move,
    ability_rules,
):
    ability_name = attacker.get("Ability")

    if not ability_name:
        return 1

    for rule in ability_rules:
        if rule.get("Ability") != ability_name:
            continue

        if rule.get("Effect") != "AttackBoost":
            continue

        if rule.get("TargetType") == move.get("Category"):
            return rule.get(
                "Modifier",
                1,
            )

    return 1


def get_attack_reduction_multiplier(
    attacker,
    defender,
    move,
    ability_rules,
):
    defender_ability = defender.get("Ability")

    if not defender_ability:
        return 1

    for rule in ability_rules:
        if rule.get("Ability") != defender_ability:
            continue

        if rule.get("Effect") != "AttackReduction":
            continue

        if rule.get("TargetType") == move.get("Category"):
            return rule.get(
                "Modifier",
                1,
            )

    return 1


def get_move_power_multiplier(
    attacker,
    move,
    ability_rules,
):
    ability_name = attacker.get("Ability")

    if not ability_name:
        return 1

    for rule in ability_rules:
        if rule.get("Ability") != ability_name:
            continue

        if rule.get("Effect") != "PowerBoost":
            continue

        if (
            rule.get("TargetType") == "LowPower"
            and move.get("Power", 0) <= 60
        ):
            return rule.get(
                "Modifier",
                1,
            )

    return 1